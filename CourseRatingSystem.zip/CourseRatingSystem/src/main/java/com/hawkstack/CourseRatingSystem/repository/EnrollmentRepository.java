package com.hawkstack.CourseRatingSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hawkstack.CourseRatingSystem.model.Enrollment;

public interface EnrollmentRepository extends JpaRepository<Enrollment, Long>{
	boolean existsByUserIdAndCourseId(Long userId, Long courseId);

}
