package com.hawkstack.CourseRatingSystem;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CourseRatingApplication 
{
    public static void main( String[] args )
    {
    	SpringApplication.run(CourseRatingApplication.class, args);
    }
}
