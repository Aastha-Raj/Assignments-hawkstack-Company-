package com.hawkstack.CourseRatingSystem.service;

import org.springframework.stereotype.Service;

import com.hawkstack.CourseRatingSystem.dto.RatingRequest;
import com.hawkstack.CourseRatingSystem.dto.RatingSummary;
import com.hawkstack.CourseRatingSystem.model.Rating;
import com.hawkstack.CourseRatingSystem.repository.EnrollmentRepository;
import com.hawkstack.CourseRatingSystem.repository.RatingRepository;

@Service
public class RatingService {


	    private final RatingRepository ratingRepo;
	    private final EnrollmentRepository enrollRepo;

	    public RatingService(RatingRepository ratingRepo, EnrollmentRepository enrollRepo) {
	        this.ratingRepo = ratingRepo;
	        this.enrollRepo = enrollRepo;
	    }

	    public String rateCourse(Long courseId, RatingRequest req) {

	        // 1. Check enrollment
	        boolean enrolled = enrollRepo.existsByUserIdAndCourseId(req.getUserId(), courseId);
	        if (!enrolled) {
	            return "User not enrolled in this course!";
	        }

	        // 2. Check existing rating
	        Rating rating = ratingRepo.findByUserIdAndCourseId(req.getUserId(), courseId)
	                .orElse(new Rating());

	        rating.setUserId(req.getUserId());
	        rating.setCourseId(courseId);
	        rating.setRating(req.getRating());
	        rating.setReview(req.getReview());

	        ratingRepo.save(rating);

	        return "Rating saved successfully!";
	    }

	    public RatingSummary getCourseRating(Long courseId) {

	        RatingSummary summary = new RatingSummary();
	        summary.setCourseId(courseId);

	        Long total = ratingRepo.countByCourseId(courseId);
	        Double avg = ratingRepo.findAverageRatingByCourseId(courseId);

	        summary.setAverage(avg == null ? 0.0 : avg);
	        summary.setTotalRatings(total);

	        return summary;
	    }
	}


