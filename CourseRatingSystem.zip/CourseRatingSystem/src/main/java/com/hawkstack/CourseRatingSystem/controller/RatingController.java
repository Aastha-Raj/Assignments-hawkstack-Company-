package com.hawkstack.CourseRatingSystem.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hawkstack.CourseRatingSystem.dto.RatingRequest;
import com.hawkstack.CourseRatingSystem.dto.RatingSummary;
import com.hawkstack.CourseRatingSystem.service.RatingService;

@RestController
@RequestMapping("/courses")
public class RatingController {

	
	    private final RatingService service;

	    public RatingController(RatingService service) {
	        this.service = service;
	    }

	    @PostMapping("/{courseId}/rating")
	    public String rateCourse(
	            @PathVariable("courseId") Long courseId,
	            @RequestBody RatingRequest req
	    ) {
	        return service.rateCourse(courseId, req);
	    }

	    @GetMapping("/{courseId}/rating")
	    public RatingSummary getRating(@PathVariable("courseId") Long courseId) {
	        return service.getCourseRating(courseId);
	    }
	}


