package com.hawkstack.CourseRatingSystem.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hawkstack.CourseRatingSystem.model.Rating;

public interface RatingRepository extends JpaRepository<Rating, Long>{

	 Optional<Rating> findByUserIdAndCourseId(Long userId, Long courseId);

	    Long countByCourseId(Long courseId);
	    
	    @org.springframework.data.jpa.repository.Query(
	            "SELECT AVG(r.rating) FROM Rating r WHERE r.courseId = :courseId"
	    )

	    Double findAverageRatingByCourseId(Long courseId);
	    
	    
}
