package com.hawkstack.CourseRatingSystem.dto;


public class RatingRequest {

	 public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	private Integer rating;
	    private String review;
	    private Long userId;
}
