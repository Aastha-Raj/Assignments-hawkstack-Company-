package com.hawkstack.CourseRatingSystem.dto;


public class RatingSummary {

	 private Long courseId;
	    private Double average;
	    public Long getCourseId() {
			return courseId;
		}
		public void setCourseId(Long courseId) {
			this.courseId = courseId;
		}
		public Double getAverage() {
			return average;
		}
		public void setAverage(Double average) {
			this.average = average;
		}
		public Long getTotalRatings() {
			return totalRatings;
		}
		public void setTotalRatings(Long totalRatings) {
			this.totalRatings = totalRatings;
		}
		private Long totalRatings;
}

