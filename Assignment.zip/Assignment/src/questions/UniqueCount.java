package questions;

import java.util.Arrays;

public class UniqueCount {
	public static void main(String[] args) {
        int[] arr = {1, 2, 2, 3, 4, 4};

        Arrays.sort(arr);

        int uniqueCountNum = 0;

        for (int i = 0; i < arr.length; i++) {
            if (i == 0 || arr[i] != arr[i - 1]) {
                uniqueCountNum++;
            }
        }

        System.out.println("Unique elements: " + uniqueCountNum);
    }
}


