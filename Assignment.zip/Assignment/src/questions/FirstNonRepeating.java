package questions;

public class FirstNonRepeating {
    public static void main(String[] args) {
        String s = "aabbcde";

        int[] freq = new int[256];  

       
        for (char c : s.toCharArray()) {
            freq[c]++;
        }

        
        Character result = null;

        for (char c : s.toCharArray()) {
            if (freq[c] == 1) {
                result = c;
                break;
            }
        }

        System.out.println(result); 
    }
}
