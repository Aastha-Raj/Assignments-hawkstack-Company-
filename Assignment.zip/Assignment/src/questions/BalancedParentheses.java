package questions;

public class BalancedParentheses {

    public static void main(String[] args) {
        
        String s = "(()())";

        int count = 0;

        for (char c : s.toCharArray()) {
            if (c == '(') {
                count++;
            } else if (c == ')') {
                count--;

                if (count < 0) { 
                    System.out.println(false);
                    return;
                }
            }
        }

        System.out.println(count == 0);
    }
}
