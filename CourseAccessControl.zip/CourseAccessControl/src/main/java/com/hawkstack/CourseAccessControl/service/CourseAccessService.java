package com.hawkstack.CourseAccessControl.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hawkstack.CourseAccessControl.model.Lesson;
import com.hawkstack.CourseAccessControl.repository.EnrollmentRepository;
import com.hawkstack.CourseAccessControl.repository.LessonRepository;

@Service
public class CourseAccessService {

	

	    private final EnrollmentRepository enrollmentRepo;
	    private final LessonRepository lessonRepo;

	    public CourseAccessService(EnrollmentRepository enrollmentRepo, LessonRepository lessonRepo) {
	        this.enrollmentRepo = enrollmentRepo;
	        this.lessonRepo = lessonRepo;
	    }

	    public List<Lesson> getLessonsForUser(Long userId, Long courseId) {
	        boolean enrolled = enrollmentRepo.existsByUserIdAndCourseId(userId, courseId);
	        if (!enrolled) {
	            throw new SecurityException("User not enrolled");
	        }
	        return lessonRepo.findByCourseId(courseId);
	    }
	}


