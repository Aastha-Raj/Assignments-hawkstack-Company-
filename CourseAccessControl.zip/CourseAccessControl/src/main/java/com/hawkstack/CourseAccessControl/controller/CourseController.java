package com.hawkstack.CourseAccessControl.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hawkstack.CourseAccessControl.model.Lesson;
import com.hawkstack.CourseAccessControl.service.CourseAccessService;

@RestController
@RequestMapping("/courses")
public class CourseController {


	    private final CourseAccessService service;

	    public CourseController(CourseAccessService service) {
	        this.service = service;
	    }

	    // Simple auth substitute: pass X-User-Id header with user id
	    @GetMapping("/{courseId}/lessons")
	    public ResponseEntity<?> getLessons(
	            @PathVariable("courseId") Long courseId,
	            @RequestHeader("userId") Long userId
	    ) {
	        try {
	            List<Lesson> lessons = service.getLessonsForUser(userId, courseId);
	            return ResponseEntity.ok(lessons);
	        } catch (SecurityException ex) {
	            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Forbidden: user not enrolled");
	        }
	    }
	}


