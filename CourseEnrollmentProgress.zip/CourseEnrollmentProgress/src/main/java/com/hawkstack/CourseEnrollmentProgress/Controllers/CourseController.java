package com.hawkstack.CourseEnrollmentProgress.Controllers;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hawkstack.CourseEnrollmentProgress.Services.EnrollmentService;
import com.hawkstack.CourseEnrollmentProgress.Services.LessonCompletionService;
import com.hawkstack.CourseEnrollmentProgress.model.Enrollment;
import com.hawkstack.CourseEnrollmentProgress.model.LessonCompletion;


@RestController
@RequestMapping("/courses")
public class CourseController {
    private final EnrollmentService enrollmentService;
    private final LessonCompletionService completionService;
    
    public CourseController(EnrollmentService enrollmentService,
            LessonCompletionService completionService)
    {
this.enrollmentService = enrollmentService;
this.completionService = completionService;
}
    

    // Enroll: here we assume userId is provided in body or header; replace with real auth
    @PostMapping("/{courseId}/enroll")
    public ResponseEntity<?> enroll(@PathVariable Long courseId,
                                    @RequestParam Long userId) {
        Enrollment e = enrollmentService.enroll(userId, courseId);
        return ResponseEntity.ok(Map.of(
            "message", "enrolled",
            "enrollmentId", e.getId(),
            "enrolledAt", e.getEnrolledAt()
        ));
    }

    @PostMapping("/{courseId}/lessons/{lessonId}/complete")
    public ResponseEntity<?> completeLesson(@PathVariable Long courseId,
                                            @PathVariable Long lessonId,
                                            @RequestParam Long userId) {
        LessonCompletion lc = completionService.completeLesson(userId, courseId, lessonId);
        return ResponseEntity.ok(Map.of(
            "message", "completed",
            "completedAt", lc.getCompletedAt()
        ));
    }

}
