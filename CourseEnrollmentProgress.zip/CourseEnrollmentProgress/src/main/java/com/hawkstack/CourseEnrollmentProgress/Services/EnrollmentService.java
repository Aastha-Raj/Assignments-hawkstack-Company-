package com.hawkstack.CourseEnrollmentProgress.Services;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.hawkstack.CourseEnrollmentProgress.Exception.ResourceNotFoundException;
import com.hawkstack.CourseEnrollmentProgress.Repositories.CourseRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.EnrollmentRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.UserRepository;
import com.hawkstack.CourseEnrollmentProgress.model.Course;
import com.hawkstack.CourseEnrollmentProgress.model.Enrollment;
import com.hawkstack.CourseEnrollmentProgress.model.User;

import jakarta.transaction.Transactional;

@Service
public class EnrollmentService {
    private final EnrollmentRepository enrollmentRepo;
    private final UserRepository userRepo;
    private final CourseRepository courseRepo;
    
    public EnrollmentService(EnrollmentRepository enrollmentRepo,
            UserRepository userRepo,
            CourseRepository courseRepo) {
this.enrollmentRepo = enrollmentRepo;
this.userRepo = userRepo;
this.courseRepo = courseRepo;
}

    @Transactional
    public Enrollment enroll(Long userId, Long courseId) {
        // validate user & course
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Course course = courseRepo.findById(courseId)
            .orElseThrow(() -> new ResourceNotFoundException("Course not found"));

        // Try find existing
        Optional<Enrollment> existing = enrollmentRepo.findByUserIdAndCourseId(userId, courseId);
        if (existing.isPresent()) {
            return existing.get();
        }

        // create and save; race condition handled by DB unique constraint
        Enrollment enrollment = new Enrollment();
        enrollment.setUser(user);
        enrollment.setCourse(course);
        enrollment.setEnrolledAt(LocalDateTime.now());
        try {
            return enrollmentRepo.save(enrollment);
        } catch (DataIntegrityViolationException ex) {
            // concurrent insert by another thread/process -> fetch existing and return
            return enrollmentRepo.findByUserIdAndCourseId(userId, courseId)
                .orElseThrow(() -> new RuntimeException("Enrollment failed and not found"));
        }
    }
}
