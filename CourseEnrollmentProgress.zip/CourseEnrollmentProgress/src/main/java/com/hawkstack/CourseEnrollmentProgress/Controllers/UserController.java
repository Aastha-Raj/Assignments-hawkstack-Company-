package com.hawkstack.CourseEnrollmentProgress.Controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hawkstack.CourseEnrollmentProgress.DTOs.ProgressDto;
import com.hawkstack.CourseEnrollmentProgress.Services.LessonCompletionService;


@RestController

@RequestMapping("/users")
public class UserController {
    private final LessonCompletionService completionService;
    
    public UserController(LessonCompletionService completionService) {
        this.completionService = completionService;
    }

    @GetMapping("/{userId}/courses/{courseId}/progress")
    public ResponseEntity<ProgressDto> progress(@PathVariable Long userId,
                                                @PathVariable Long courseId) {
        ProgressDto dto = completionService.getProgress(userId, courseId);
        return ResponseEntity.ok(dto);
    }
}

