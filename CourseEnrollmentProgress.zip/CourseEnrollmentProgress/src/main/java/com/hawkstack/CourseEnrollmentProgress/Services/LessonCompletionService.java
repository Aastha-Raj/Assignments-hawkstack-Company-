package com.hawkstack.CourseEnrollmentProgress.Services;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.hawkstack.CourseEnrollmentProgress.DTOs.ProgressDto;
import com.hawkstack.CourseEnrollmentProgress.Exception.BadRequestException;
import com.hawkstack.CourseEnrollmentProgress.Exception.ForbiddenException;
import com.hawkstack.CourseEnrollmentProgress.Exception.ResourceNotFoundException;
import com.hawkstack.CourseEnrollmentProgress.Repositories.CourseRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.EnrollmentRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.LessonCompletionRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.LessonRepository;
import com.hawkstack.CourseEnrollmentProgress.Repositories.UserRepository;
import com.hawkstack.CourseEnrollmentProgress.model.Course;
import com.hawkstack.CourseEnrollmentProgress.model.Lesson;
import com.hawkstack.CourseEnrollmentProgress.model.LessonCompletion;
import com.hawkstack.CourseEnrollmentProgress.model.User;

import jakarta.transaction.Transactional;

@Service
public class LessonCompletionService {
    private final LessonCompletionRepository completionRepo;
    private final EnrollmentRepository enrollmentRepo;
    private final LessonRepository lessonRepo;
    private final UserRepository userRepo;
    private final CourseRepository courseRepo;
    
    public LessonCompletionService(
            LessonCompletionRepository completionRepo,
            EnrollmentRepository enrollmentRepo,
            LessonRepository lessonRepo,
            UserRepository userRepo,
            CourseRepository courseRepo) {

        this.completionRepo = completionRepo;
        this.enrollmentRepo = enrollmentRepo;
        this.lessonRepo = lessonRepo;
        this.userRepo = userRepo;
        this.courseRepo = courseRepo;
    }

    @Transactional
    public LessonCompletion completeLesson(Long userId, Long courseId, Long lessonId) {
        // validations
        User user = userRepo.findById(userId)
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Course course = courseRepo.findById(courseId)
            .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
        
        Lesson lesson = lessonRepo.findById(lessonId)
            .orElseThrow(() -> new ResourceNotFoundException("Lesson not found"));

        // check lesson belongs to course
        if (!lesson.getCourse().getId().equals(courseId)) {
            throw new BadRequestException("Lesson does not belong to course");
        }

        // optional: ensure user enrolled (business choice)
        boolean enrolled = enrollmentRepo.findByUserIdAndCourseId(userId, courseId).isPresent();
        if (!enrolled) {
            throw new ForbiddenException("User not enrolled in course");
        }

        // check existing completion
        Optional<LessonCompletion> existing = completionRepo.findByUserIdAndLessonId(userId, lessonId);
        if (existing.isPresent()) {
            return existing.get();
        }

        // create and save; handle concurrency via unique constraint
        LessonCompletion completion = new LessonCompletion();
        completion.setUser(user);
        completion.setCourse(course);
        completion.setLesson(lesson);
        completion.setCompletedAt(LocalDateTime.now());

        try {
            return completionRepo.save(completion);
        } catch (DataIntegrityViolationException ex) {
            // concurrent write: fetch existing
            return completionRepo.findByUserIdAndLessonId(userId, lessonId)
                .orElseThrow(() -> new RuntimeException("Completion failed and not found"));
        }
    }

    public ProgressDto getProgress(Long userId, Long courseId) {
        long total = lessonRepo.countByCourseId(courseId);
        long completed = completionRepo.countByUserIdAndCourseId(userId, courseId);
        List<LessonCompletion> list = completionRepo.findByUserIdAndCourseIdOrderByCompletedAt(userId, courseId);
        List<Long> completedIds = list.stream()
            .map(lc -> lc.getLesson().getId())
            .toList();

        int percent = total == 0 ? 0 : (int) ((completed * 100) / total);
        return new ProgressDto(userId, courseId, total, completed, percent, completedIds);
    }
}
