package com.hawkstack.CourseEnrollmentProgress.Exception;


public class BadRequestException extends RuntimeException {
    public BadRequestException(String msg) {
        super(msg);
    }
}
