package com.hawkstack.CourseEnrollmentProgress.Repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hawkstack.CourseEnrollmentProgress.model.Lesson;

public interface LessonRepository extends JpaRepository<Lesson, Long> {
    Optional<Lesson> findByIdAndCourseId(Long id, Long courseId);
    long countByCourseId(Long courseId);
}



