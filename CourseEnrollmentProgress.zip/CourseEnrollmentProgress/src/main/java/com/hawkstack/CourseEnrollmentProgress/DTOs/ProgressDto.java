package com.hawkstack.CourseEnrollmentProgress.DTOs;


import java.util.List;

import lombok.Data;

@Data
public class ProgressDto {

    private Long userId;
    private Long courseId;
    private long totalLessons;
    private long completedLessons;
    private int percentage;
    private List<Long> completedLessonIds;
    
    public ProgressDto(Long userId, Long courseId, long totalLessons, long completedLessons,
            int percentage, List<Long> completedLessonIds) {
this.userId = userId;
this.courseId = courseId;
this.totalLessons = totalLessons;
this.completedLessons = completedLessons;
this.percentage = percentage;
this.completedLessonIds = completedLessonIds;
}

}
