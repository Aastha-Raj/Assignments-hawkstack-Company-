package com.hawkstack.CourseEnrollmentProgress.Repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hawkstack.CourseEnrollmentProgress.model.LessonCompletion;

public interface LessonCompletionRepository extends JpaRepository<LessonCompletion, Long> {
    Optional<LessonCompletion> findByUserIdAndLessonId(Long userId, Long lessonId);
    long countByUserIdAndCourseId(Long userId, Long courseId);
    List<LessonCompletion> findByUserIdAndCourseIdOrderByCompletedAt(Long userId, Long courseId);
}



